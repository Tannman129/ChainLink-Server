package com.fortsprague.discgolf

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import com.fortsprague.discgolf.ui.DiscGolfApp
import com.fortsprague.discgolf.ui.about.AboutScreen
import com.fortsprague.discgolf.ui.home.HomeScreen
import com.fortsprague.discgolf.ui.theme.DiscGolfTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

class BrandingScreenTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    private fun assertNotClipped(node: SemanticsNodeInteraction, text: String) {
        val layouts = mutableListOf<androidx.compose.ui.text.TextLayoutResult>()
        node.performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.GetTextLayoutResult) { it(layouts) }
        assertTrue("Text layout unavailable: $text", layouts.isNotEmpty())
        layouts.forEach { layout ->
            assertFalse("Clipped height: $text", layout.didOverflowHeight)
            // As in UiReadabilityTest, check painted lines: centered Text can keep
            // a wider paragraph constraint after its measured bounds shrink to fit.
            for (line in 0 until layout.lineCount) {
                assertTrue("Clipped line: $text", layout.getLineRight(line) - layout.getLineLeft(line) <= layout.size.width + 1)
            }
        }
    }

    private fun screenshot(name: String) {
        compose.waitForIdle()
        val instrumentation = androidx.test.platform.app.InstrumentationRegistry.getInstrumentation()
        val bitmap = requireNotNull(instrumentation.uiAutomation.takeScreenshot())
        java.io.File(instrumentation.targetContext.cacheDir, "branding-$name.png").outputStream().use {
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
        }
        bitmap.recycle()
    }

    @Test fun logoPreservesDimensionsDarkDetailsAndSmoothTransparency() {
        compose.setContent { DiscGolfTheme { AboutScreen({}) } }
        val bitmap = android.graphics.BitmapFactory.decodeResource(compose.activity.resources, R.drawable.qcb_logo)
        assertEquals(941, bitmap.width)
        assertEquals(1670, bitmap.height)
        assertTrue(bitmap.hasAlpha())
        for ((x, y) in listOf(0 to 0, 940 to 0, 0 to 1669, 940 to 1669)) {
            assertEquals(0, android.graphics.Color.alpha(bitmap.getPixel(x, y)))
        }
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        assertTrue("Dark artwork details must stay opaque", pixels.count {
            android.graphics.Color.alpha(it) == 255 && android.graphics.Color.red(it) < 20 &&
                android.graphics.Color.green(it) < 20 && android.graphics.Color.blue(it) < 20
        } > 10_000)
        assertTrue("White artwork must stay opaque", pixels.count {
            android.graphics.Color.alpha(it) == 255 && android.graphics.Color.red(it) > 240 &&
                android.graphics.Color.green(it) > 240 && android.graphics.Color.blue(it) > 240
        } > 100_000)
        assertTrue("Edges need fractional alpha", pixels.count { android.graphics.Color.alpha(it) in 1..254 } > 100)
        bitmap.recycle()
    }

    @Test fun officialArtworkKeepsItsFullFrameAndHomeActions() {
        var started = false
        var history = false
        var courses = false
        compose.setContent { DiscGolfTheme {
            HomeScreen({ started = true }, { history = true }, { courses = true })
        } }
        compose.onNodeWithContentDescription("ChainLink Midnight Red disc golf basket artwork")
            .performScrollTo().assertIsDisplayed()
        val bitmap = android.graphics.BitmapFactory.decodeResource(compose.activity.resources, R.drawable.chainlink_basket)
        assertEquals(720, bitmap.width)
        assertEquals(881, bitmap.height)
        bitmap.recycle()
        compose.onNodeWithText("Start Round").performScrollTo().performClick()
        compose.onNodeWithText("Round History").performScrollTo().performClick()
        compose.onNodeWithText("Manage Courses").performScrollTo().performClick()
        compose.runOnIdle { assertTrue(started && history && courses) }
    }

    @Test fun launcherUsesAdaptiveArtworkForBothIconShapes() {
        val resources = compose.activity.resources
        for (id in listOf(R.mipmap.ic_launcher, R.mipmap.ic_launcher_round)) {
            val icon = resources.getDrawable(id, compose.activity.theme)
            assertTrue(icon is android.graphics.drawable.AdaptiveIconDrawable)
            icon as android.graphics.drawable.AdaptiveIconDrawable
            assertNotNull(icon.background)
            assertNotNull(icon.foreground)
        }
        val options = android.graphics.BitmapFactory.Options().apply { inScaled = false }
        val bitmap = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.ic_launcher_artwork, options)
        assertEquals(bitmap.width, bitmap.height)
        assertTrue(bitmap.hasAlpha())
        assertEquals(0, android.graphics.Color.alpha(bitmap.getPixel(0, 0)))
        bitmap.recycle()
    }

    @Test fun homeCreditAndBothBackControls() {
        compose.setContent { DiscGolfTheme { DiscGolfApp() } }
        val credit = compose.onNodeWithText("Created by the Quaker Chainbangers")
        credit.assertHasClickAction().assertHeightIsAtLeast(48.dp).performScrollTo()
        screenshot("home")
        credit.performClick()
        compose.onNodeWithText("About ChainLink").assertIsDisplayed()
        compose.onAllNodesWithText("Created by the Quaker Chainbangers").assertCountEquals(1)
        compose.onNodeWithText("Created by the Quaker Chainbangers.").assertDoesNotExist()
        compose.onNodeWithText("by Quaker Chainbangers").assertDoesNotExist()
        compose.onNodeWithContentDescription("Quaker Chainbangers official logo").assertIsDisplayed()
        screenshot("about")
        compose.onNodeWithText("Back").performClick()
        credit.performScrollTo().performClick()
        compose.onNodeWithText("About ChainLink").assertIsDisplayed()
        compose.runOnUiThread { compose.activity.onBackPressedDispatcher.onBackPressed() }
        credit.assertExists()
        listOf("Start Round", "Round History", "Manage Courses").forEach {
            compose.onNodeWithText(it).performScrollTo().assertIsDisplayed().assertHasClickAction()
        }
    }

    @Test fun narrowScreenAtDoubleFontScaleScrollsThroughAllContent() {
        val version = compose.activity.packageManager
            .getPackageInfo(compose.activity.packageName, 0).versionName
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, 2f)) {
                DiscGolfTheme { Box(Modifier.width(320.dp)) { AboutScreen({}) } }
            }
        }
        compose.onAllNodesWithText("Created by the Quaker Chainbangers").assertCountEquals(1)
        compose.onNodeWithText("Created by the Quaker Chainbangers.").assertDoesNotExist()
        screenshot("about-narrow-top")
        listOf("ChainLink", "Created by the Quaker Chainbangers", "Version $version",
            "\"WE'RE HERE FOR THE CHAINBANG!\"",
            "ChainLink is a free, open-source disc golf scorekeeper built for players who would rather be throwing discs than fighting with an app. Fast scoring, simple course management, and no internet required.",
            "View ChainLink on GitHub").forEach {
            val node = compose.onNodeWithText(it).performScrollTo().assertIsDisplayed()
            assertNotClipped(node, it)
            if (it == "\"WE'RE HERE FOR THE CHAINBANG!\"") screenshot("about-narrow-credit")
        }
        compose.onNodeWithText("View ChainLink on GitHub").assertHasClickAction()
        compose.onNodeWithText("Back").assertIsDisplayed()
    }

    @Test fun narrowHomeCreditWrapsWithoutClippingAndKeepsTouchTarget() {
        var opened = false
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, 2f)) {
                DiscGolfTheme { Box(Modifier.width(320.dp)) {
                    HomeScreen({}, {}, {}, onAbout = { opened = true })
                } }
            }
        }
        val credit = compose.onNodeWithText("Created by the Quaker Chainbangers")
            .performScrollTo().assertIsDisplayed().assertHeightIsAtLeast(48.dp)
        assertNotClipped(credit, "Home creator credit")
        screenshot("home-narrow")
        credit.performClick()
        compose.runOnIdle { assertTrue(opened) }
    }
}
