package com.fortsprague.discgolf.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import com.fortsprague.discgolf.data.rounds.RoundDetails
import com.fortsprague.discgolf.ui.rounds.RoundCard
import com.fortsprague.discgolf.ui.rounds.DeleteRoundConfirmation
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import com.fortsprague.discgolf.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.fortsprague.discgolf.ui.theme.DiscGolfTheme

@Composable
fun HomeScreen(
    onStartRound: () -> Unit,
    onRoundHistory: () -> Unit,
    onManageCourses: () -> Unit,
    modifier: Modifier = Modifier,
    unfinishedRounds: List<RoundDetails> = emptyList(),
    onResume: (Long) -> Unit = {},
    onFinish: (Long) -> Unit = {},
    onDelete: (Long, () -> Unit) -> Unit = { _, _ -> },
    busy: Boolean = false, error: String? = null, onRetry: () -> Unit = {},
    onAbout: () -> Unit = {}
) {
    var deletingId by rememberSaveable { mutableStateOf<Long?>(null) }
    val deleting = unfinishedRounds.find { it.round.id == deletingId }
    if (deleting != null) DeleteRoundConfirmation(deleting, busy, error,
        onDelete = { onDelete(deleting.round.id) { deletingId = null } }, onCancel = { deletingId = null })
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.chainlink_basket),
                contentDescription = "ChainLink Midnight Red disc golf basket artwork",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(width = 148.dp, height = 181.dp)
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                TextButton(onClick = onAbout, modifier = Modifier.heightIn(min = 48.dp),
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onSurfaceVariant)) {
                    Text("Created by the Quaker Chainbangers", style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center)
                }
            }
            Text("Your round. Your rules.", style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (unfinishedRounds.isNotEmpty()) Text("Unfinished Rounds", style = MaterialTheme.typography.titleMedium)
                unfinishedRounds.forEach { round ->
                    RoundCard(round, !busy, onOpen = { onResume(round.round.id) },
                        onFinish = { onFinish(round.round.id) }, onDelete = { deletingId = round.round.id })
                }
                Button(
                    onClick = onStartRound,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(20.dp)
                ) {
                    Text("Start Round", style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                    OutlinedButton(onClick = onRetry, enabled = !busy) { Text("Retry") }
                }
                HomeSecondaryButton("Round History", onRoundHistory)
                HomeSecondaryButton("Manage Courses", onManageCourses)
            }
        }
    }
}

@Composable
private fun HomeSecondaryButton(label: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().heightIn(min = 68.dp),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        contentPadding = PaddingValues(20.dp)
    ) {
        Text(label, style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

@Preview(showBackground = true)
@Composable
private fun HomeScreenPreview() {
    DiscGolfTheme {
        androidx.compose.material3.Surface {
            HomeScreen({}, {}, {})
        }
    }
}
